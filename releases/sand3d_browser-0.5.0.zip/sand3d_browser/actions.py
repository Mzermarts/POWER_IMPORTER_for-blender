"""Import, preview preparation and integration with Blender's Asset Browser."""
from pathlib import Path
import os
import subprocess
import uuid
import hashlib
import re
import bpy
import bpy.utils.previews
from . import blender_ui as ui
from .catalog import local_root
from .model_io import import_model, checked_asset, dependencies, SUPPORTED

PREVIEWS = None
READY = {}
JOB = None


def selected(context):
    state = context.window_manager.sand3d_state
    if not 0 <= state.selected < len(state.results):
        raise ValueError('Sélectionnez un modèle')
    item = state.results[state.selected]
    if not hasattr(item, 'library_uid') or not hasattr(item, 'root'):
        raise ValueError('Ancienne version encore chargée : enregistrer le travail, redémarrer Blender puis réindexer')
    lib = next((l for l in ui.preferences(context).libraries if l.uid == item.library_uid), None)
    if lib is None or not lib.enabled or lib.directory != item.root:
        raise ValueError('Bibliothèque modifiée : relancez la recherche')
    return item


def key(item):
    return (getattr(item, 'root', ''), item.relative_path)


def selected_scale(context, item):
    return next(lib.unitless_scale for lib in ui.preferences(context).libraries if lib.uid == item.library_uid)


def icon(item):
    prepared = READY.get(key(item))
    if PREVIEWS is not None and prepared and prepared in PREVIEWS:
        return PREVIEWS[prepared].icon_id
    return 0


class S3D_OT_import(bpy.types.Operator):
    bl_idname = 'sand3d.import_selected'
    bl_label = 'Importer dans la scène'
    bl_description = 'Importer le modèle sélectionné dans une nouvelle collection'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.mode != 'OBJECT':
            self.report({'WARNING'}, 'Passez en mode Objet avant l’import')
            return {'CANCELLED'}
        try:
            item = selected(context)
            collection, objects = import_model(context, item.root, item.relative_path, selected_scale(context, item))
            context.window_manager.sand3d_state.status = f'{len(objects)} objet(s) importé(s) : {collection.name}'
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


def refresh_job():
    global JOB
    if JOB is None:
        return None
    process, handle, output, item_key = JOB
    if process.poll() is None:
        return 0.5
    handle.close()
    JOB = None
    state = bpy.context.window_manager.sand3d_state
    if process.returncode == 0 and output.with_suffix('.blend').is_file():
        READY[item_key] = str(output)
        PREVIEWS.load(str(output), str(output.with_suffix('.png')), 'IMAGE')
        state.status = 'Miniature prête. Ouvrez l’Asset Browser pour glisser-déposer.'
    else:
        state.status = 'Préparation échouée : consulter ' + str(output.with_suffix('.log'))
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            area.tag_redraw()
    return None


class S3D_OT_prepare(bpy.types.Operator):
    bl_idname = 'sand3d.prepare_asset'
    bl_label = 'Créer miniature et asset glissable'
    bl_description = 'Créer un aperçu et une copie Blender dans le dossier préparé, sans modifier la source'

    def execute(self, context):
        global JOB
        if JOB is not None:
            self.report({'WARNING'}, 'Une préparation est déjà en cours')
            return {'CANCELLED'}
        try:
            item = selected(context)
            source_path, resources = dependencies(item.root, item.relative_path)
            prefs = ui.preferences(context)
            output_root = local_root(prefs.prepared_directory)
            # Never mix generated output into a source library.
            for lib in prefs.libraries:
                if lib.directory:
                    source = local_root(lib.directory)
                    if output_root.is_relative_to(source) or source.is_relative_to(output_root):
                        raise ValueError('Choisir un dossier de préparation distinct des sources')
            libraries = context.preferences.filepaths.asset_libraries
            if not any(Path(l.path) == output_root for l in libraries):
                libraries.new(name='MZERMARTS Sand3D', directory=str(output_root))
            scale = selected_scale(context, item)
            records = [(str(p), p.stat().st_mtime_ns, p.stat().st_size) for p in sorted(resources)]
            fingerprint = hashlib.sha256(repr(('0.5', records, scale)).encode()).hexdigest()[:16]
            stem = re.sub(r'[^\w-]+', '_', source_path.stem)[:60]
            output = output_root / (stem + '_' + fingerprint)
            if output.with_suffix('.blend').is_file() and output.with_suffix('.png').is_file():
                READY[key(item)] = str(output)
                if str(output) not in PREVIEWS:
                    PREVIEWS.load(str(output), str(output.with_suffix('.png')), 'IMAGE')
                context.window_manager.sand3d_state.status = 'Asset préparé retrouvé dans le cache.'
                return {'FINISHED'}
            profile = output_root / ('profil_' + uuid.uuid4().hex)
            env = os.environ.copy()
            for variable, suffix in {
                'BLENDER_USER_RESOURCES': '', 'BLENDER_USER_CONFIG': 'config',
                'BLENDER_USER_SCRIPTS': 'scripts', 'BLENDER_USER_EXTENSIONS': 'extensions',
                'BLENDER_USER_DATAFILES': 'datafiles',
            }.items():
                folder = profile / suffix
                folder.mkdir(parents=True, exist_ok=True)
                env[variable] = str(folder)
            args = [bpy.app.binary_path, '--background', '--factory-startup', '--disable-autoexec',
                    '--python-exit-code', '1', '--python', str(Path(__file__).with_name('prepare_asset.py')),
                    '--', item.root, item.relative_path, str(output), str(scale)]
            log = output.with_suffix('.log').open('x', encoding='utf-8')
            try:
                process = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT, env=env,
                                           creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
            except Exception:
                log.close()
                raise
            JOB = process, log, output, key(item)
            context.window_manager.sand3d_state.status = 'Préparation en arrière-plan…'
            bpy.app.timers.register(refresh_job, first_interval=0.5)
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


class S3D_OT_copy_path(bpy.types.Operator):
    bl_idname = 'sand3d.copy_path'
    bl_label = 'Copier le chemin du modèle'

    def execute(self, context):
        try:
            item = selected(context)
            context.window_manager.clipboard = str(Path(item.root) / item.relative_path)
            return {'FINISHED'}
        except ValueError as exc:
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}


class S3D_OT_asset_browser(bpy.types.Operator):
    bl_idname = 'sand3d.open_asset_browser'
    bl_label = 'Ouvrir l’Asset Browser'
    bl_description = 'Ouvrir une fenêtre Blender dédiée aux assets préparés'

    def execute(self, context):
        if context.window is None:
            return {'CANCELLED'}
        before = set(context.window_manager.windows)
        bpy.ops.wm.window_new()
        window = next((w for w in context.window_manager.windows if w not in before), None)
        if window is None:
            return {'CANCELLED'}
        area = max(window.screen.areas, key=lambda a: a.width * a.height)
        area.type = 'FILE_BROWSER'
        area.ui_type = 'ASSETS'
        # ALL is robust even when another library has the same display name.
        if area.spaces.active.params is not None:
            area.spaces.active.params.asset_library_reference = 'ALL'
        return {'FINISHED'}


def draw_actions(layout, context):
    supported = False
    try:
        supported = selected(context).format in SUPPORTED
    except ValueError:
        pass
    row = layout.column()
    row.enabled = supported
    row.operator('sand3d.import_selected', icon='IMPORT')
    row.operator('sand3d.prepare_asset', icon='RENDER_STILL')
    layout.operator('sand3d.open_asset_browser', icon='ASSET_MANAGER')
    layout.operator('sand3d.copy_path', icon='COPYDOWN')


def list_context_menu(self, context):
    listing = getattr(context, 'ui_list', None)
    if listing and listing.bl_idname == 'S3D_UL_results':
        self.layout.separator()
        draw_actions(self.layout, context)


CLASSES = (S3D_OT_import, S3D_OT_prepare, S3D_OT_copy_path, S3D_OT_asset_browser)


def register():
    global PREVIEWS
    PREVIEWS = bpy.utils.previews.new()
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.UI_MT_list_item_context_menu.append(list_context_menu)


def unregister():
    global PREVIEWS, JOB
    # Stop the isolated worker without touching source files or deleting output.
    if JOB is not None:
        process, handle, output, item_key = JOB
        process.terminate()
        process.wait(timeout=10)
        handle.close()
        JOB = None
    if bpy.app.timers.is_registered(refresh_job):
        bpy.app.timers.unregister(refresh_job)
    bpy.types.UI_MT_list_item_context_menu.remove(list_context_menu)
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
    bpy.utils.previews.remove(PREVIEWS)
    PREVIEWS = None
    READY.clear()
