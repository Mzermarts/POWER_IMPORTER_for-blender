"""Local library browser; no network access or execution of asset code."""

bl_info = {
    "name": "MZERMARTS Sand3D Browser",
    "author": "MZERMARTS",
    "version": (0, 1, 1),
    "blender": (5, 0, 0),
    "location": "Preferences > Add-ons; View3D > Sidebar > Sand3D",
    "description": "Configure local libraries and search their model files",
    "category": "3D View",
}


def register():
    from . import blender_ui
    blender_ui.register()


def unregister():
    from . import blender_ui
    blender_ui.unregister()
