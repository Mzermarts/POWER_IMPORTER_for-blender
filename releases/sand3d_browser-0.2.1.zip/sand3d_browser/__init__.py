"""Local library browser; no network access or execution of asset code."""

bl_info = {
    "name": "MZERMARTS Sand3D Browser",
    "author": "MZERMARTS",
    "version": (0, 2, 1),
    "blender": (5, 0, 0),
    "location": "Preferences > Add-ons; View3D > Sidebar > Sand3D",
    "description": "Configure local libraries and search their model files",
    "category": "3D View",
}


def register():
    # Blender may reload only __init__ on an install/update. Refresh submodules
    # in dependency order after the previous version has been disabled.
    import importlib
    import sys
    for name in ('catalog', 'usd_io', 'blender_ui', 'actions'):
        qualified = __name__ + '.' + name
        if qualified in sys.modules:
            importlib.reload(sys.modules[qualified])
        else:
            importlib.import_module(qualified)
    from . import blender_ui, actions
    blender_ui.register()
    actions.register()


def unregister():
    from . import blender_ui, actions
    actions.unregister()
    blender_ui.unregister()
