"""Blender preferences and session-local index. No persistent cache yet."""
import time
import uuid
import bpy
from bpy.props import BoolProperty, CollectionProperty, IntProperty, StringProperty
from .catalog import local_root, scan, search

PACKAGE = __package__
INDEX = {}
RUNNING = False
ACTIVE_JOB = None


def invalidate(self, context):
    INDEX.pop(self.uid, None)
    if context and hasattr(context.window_manager, "sand3d_state"):
        context.window_manager.sand3d_state.results.clear()


def preferences(context):
    return context.preferences.addons[PACKAGE].preferences


class S3DLibrary(bpy.types.PropertyGroup):
    uid: StringProperty()
    name: StringProperty(name="Nom", default="Bibliothèque locale")
    directory: StringProperty(name="Dossier", subtype='DIR_PATH', update=invalidate)
    enabled: BoolProperty(name="Active", default=True, update=invalidate)
    recursive: BoolProperty(name="Inclure les sous-dossiers", default=True, update=invalidate)


class S3DResult(bpy.types.PropertyGroup):
    relative_path: StringProperty()
    library_name: StringProperty()
    format: StringProperty()
    root: StringProperty()
    library_uid: StringProperty()


class S3DState(bpy.types.PropertyGroup):
    query: StringProperty(name="Recherche", description="Mots dans les chemins des fichiers")
    results: CollectionProperty(type=S3DResult)
    selected: IntProperty(default=0)
    status: StringProperty(default="Ajoutez un dossier dans les préférences, puis indexez-le.")
    cancel: BoolProperty(default=False)


class S3D_UL_libraries(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, "enabled", text="")
        row.prop(item, "name", text="", emboss=False)


class S3DPreferences(bpy.types.AddonPreferences):
    bl_idname = PACKAGE
    libraries: CollectionProperty(type=S3DLibrary)
    active_library: IntProperty(default=0)
    prepared_directory: StringProperty(name="Dossier des assets préparés", subtype='DIR_PATH',
        description="Dossier existant distinct des sources, pour copies .blend et miniatures")

    def draw(self, context):
        layout = self.layout
        layout.label(text="Bibliothèques locales ou réseau — lecture seule")
        controls = layout.column()
        controls.enabled = not RUNNING
        row = controls.row()
        row.template_list("S3D_UL_libraries", "", self, "libraries", self, "active_library", rows=4)
        buttons = row.column(align=True)
        buttons.operator("sand3d.library_add", text="", icon='ADD')
        buttons.operator("sand3d.library_remove", text="", icon='REMOVE')
        if 0 <= self.active_library < len(self.libraries):
            lib = self.libraries[self.active_library]
            controls.prop(lib, "directory")
            controls.prop(lib, "recursive")
        layout.label(text="N’ajouter que des dossiers professionnels autorisés.")
        layout.label(text="Lecteurs mappés et chemins UNC acceptés ; liens exclus.")
        layout.label(text="Choisir les dossiers autorisés, pas la racine du serveur.")
        controls.operator("sand3d.index", icon='FILE_REFRESH')
        layout.label(text="Enregistrez les préférences selon votre réglage Blender.")
        layout.prop(self, "prepared_directory")
        layout.label(text="Préparation : copies .blend + PNG ; sources conservées.")


class S3D_OT_add(bpy.types.Operator):
    bl_idname = "sand3d.library_add"
    bl_label = "Ajouter une bibliothèque"

    def execute(self, context):
        if RUNNING:
            return {'CANCELLED'}
        prefs = preferences(context)
        lib = prefs.libraries.add()
        lib.uid = uuid.uuid4().hex
        prefs.active_library = len(prefs.libraries) - 1
        return {'FINISHED'}


class S3D_OT_remove(bpy.types.Operator):
    bl_idname = "sand3d.library_remove"
    bl_label = "Retirer le chemin de la liste"
    bl_description = "Retirer la configuration sans supprimer les fichiers du dossier"

    def execute(self, context):
        if RUNNING:
            return {'CANCELLED'}
        prefs = preferences(context)
        if not 0 <= prefs.active_library < len(prefs.libraries):
            return {'CANCELLED'}
        INDEX.pop(prefs.libraries[prefs.active_library].uid, None)
        prefs.libraries.remove(prefs.active_library)
        prefs.active_library = max(0, min(prefs.active_library, len(prefs.libraries) - 1))
        context.window_manager.sand3d_state.results.clear()
        return {'FINISHED'}


class S3D_OT_search(bpy.types.Operator):
    bl_idname = "sand3d.search"
    bl_label = "Rechercher"

    def execute(self, context):
        state = context.window_manager.sand3d_state
        state.results.clear()
        total = 0
        for lib in preferences(context).libraries:
            cached = INDEX.get(lib.uid)
            if not lib.enabled or not cached:
                continue
            if cached[:2] != (lib.directory, lib.recursive):
                continue
            for asset in search(cached[2], state.query):
                total += 1
                if len(state.results) < 500:
                    item = state.results.add()
                    item.relative_path = asset.relative_path
                    item.library_name = lib.name
                    item.format = asset.format
                    item.root = lib.directory
                    item.library_uid = lib.uid
        state.selected = 0
        state.status = f"{total} résultat(s) ; affichage limité à 500. Index en mémoire de session."
        return {'FINISHED'}


class S3D_OT_index(bpy.types.Operator):
    bl_idname = "sand3d.index"
    bl_label = "Indexer les bibliothèques actives"
    bl_description = "Lire uniquement les noms et tailles des modèles ; Échap pour arrêter"
    _timer = None
    _iterator = None

    def _work(self, context):
        prefs = preferences(context)
        seen = set()
        count = warnings = 0
        state = context.window_manager.sand3d_state
        for lib in prefs.libraries:
            if not lib.enabled:
                continue
            try:
                key = str(local_root(lib.directory)).casefold()
                if key in seen:
                    warnings += 1
                    continue
                seen.add(key)
                items = []
                for asset, warning in scan(lib.directory, lib.recursive):
                    if asset:
                        items.append(asset)
                        count += 1
                    warnings += bool(warning)
                    state.status = f"Indexation : {lib.name} — {count} modèle(s), {warnings} avertissement(s)"
                    yield
                INDEX[lib.uid] = (lib.directory, lib.recursive, items)
            except (OSError, ValueError) as exc:
                INDEX.pop(lib.uid, None)
                warnings += 1
                self.report({'WARNING'}, f"{lib.name} : {exc}")
                yield
        bpy.ops.sand3d.search()
        state.status += f" Avertissements : {warnings}."

    def execute(self, context):
        global RUNNING, ACTIVE_JOB
        if RUNNING:
            return {'CANCELLED'}
        RUNNING = True
        ACTIVE_JOB = self
        context.window_manager.sand3d_state.cancel = False
        context.window_manager.sand3d_state.results.clear()
        # Rebuild only on explicit request; no stale snapshot after an interrupted scan.
        INDEX.clear()
        self._iterator = self._work(context)
        if bpy.app.background:
            try:
                for _ in self._iterator:
                    pass
            finally:
                self.finish(context)
            return {'FINISHED'}
        self._timer = context.window_manager.event_timer_add(0.05, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def finish(self, context):
        global RUNNING, ACTIVE_JOB
        if self._iterator is not None:
            self._iterator.close()
            self._iterator = None
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        RUNNING = False
        ACTIVE_JOB = None

    def modal(self, context, event):
        if event.type == 'ESC' or context.window_manager.sand3d_state.cancel:
            self.finish(context)
            context.window_manager.sand3d_state.status = "Indexation arrêtée ; seules les bibliothèques terminées sont disponibles."
            return {'CANCELLED'}
        if event.type == 'TIMER':
            deadline = time.monotonic() + 0.02
            try:
                while time.monotonic() < deadline:
                    next(self._iterator)
            except StopIteration:
                self.finish(context)
                return {'FINISHED'}
            except Exception as exc:
                self.finish(context)
                self.report({'ERROR'}, str(exc))
                return {'CANCELLED'}
            for area in context.screen.areas:
                area.tag_redraw()
        return {'PASS_THROUGH'}

    def cancel(self, context):
        self.finish(context)


class S3D_OT_stop(bpy.types.Operator):
    bl_idname = "sand3d.stop"
    bl_label = "Arrêter l’indexation"

    def execute(self, context):
        context.window_manager.sand3d_state.cancel = True
        return {'FINISHED'}


class S3D_UL_results(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        from .actions import icon as preview_icon
        preview = preview_icon(item)
        if preview:
            layout.label(text=item.relative_path, icon_value=preview)
        else:
            layout.label(text=item.relative_path, icon='MESH_DATA')
        layout.label(text=item.library_name)


class S3D_PT_browser(bpy.types.Panel):
    bl_label = "Sand3D — Bibliothèques 0.2.1"
    bl_idname = "S3D_PT_browser"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Sand3D"

    def draw(self, context):
        layout = self.layout
        state = context.window_manager.sand3d_state
        op = layout.operator("preferences.addon_show", text="Configurer les bibliothèques", icon='PREFERENCES')
        op.module = PACKAGE
        if RUNNING:
            layout.operator("sand3d.stop", icon='CANCEL')
        else:
            layout.operator("sand3d.index", icon='FILE_REFRESH')
        col = layout.column()
        col.enabled = not RUNNING
        col.prop(state, "query", text="", icon='VIEWZOOM')
        col.operator("sand3d.search")
        col.template_list("S3D_UL_results", "", state, "results", state, "selected", rows=7)
        if 0 <= state.selected < len(state.results):
            item = state.results[state.selected]
            col.label(text=f"Format : {item.format.upper()}")
            from .actions import icon as preview_icon, draw_actions
            preview = preview_icon(item)
            if preview:
                col.template_icon(icon_value=preview, scale=8)
            draw_actions(col)
        layout.label(text=state.status)
        layout.label(text="Glisser-déposer : utiliser l’Asset Browser après préparation.")


CLASSES = (S3DLibrary, S3DResult, S3DState, S3D_UL_libraries, S3DPreferences,
           S3D_OT_add, S3D_OT_remove, S3D_OT_search, S3D_OT_index, S3D_OT_stop,
           S3D_UL_results, S3D_PT_browser)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.WindowManager.sand3d_state = bpy.props.PointerProperty(type=S3DState)


def unregister():
    if ACTIVE_JOB is not None:
        ACTIVE_JOB.finish(bpy.context)
    del bpy.types.WindowManager.sand3d_state
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
    INDEX.clear()
