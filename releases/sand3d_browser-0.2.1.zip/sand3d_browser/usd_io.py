"""USD imports restricted to the selected library; no remote asset resolver."""
from pathlib import Path
import re
import bpy
from .catalog import local_root, is_link


def checked_asset(root_value, relative):
    root = local_root(root_value)
    rel = Path(relative)
    if rel.is_absolute() or '..' in rel.parts:
        raise ValueError('Chemin de modèle hors bibliothèque')
    path = root / rel
    for part in (path, *path.parents):
        if part == root:
            break
        if is_link(part):
            raise ValueError('Ressource liée refusée')
    path = path.resolve(strict=True)
    if not path.is_relative_to(root):
        raise ValueError('Modèle hors bibliothèque')
    if path.suffix.lower() not in {'.usd', '.usda', '.usdc'}:
        raise ValueError('Import disponible pour USD, USDA et USDC dans cette version')
    # Open only the layer itself, without composing references or payloads.
    from pxr import Sdf
    pending, visited = [path], set()
    while pending:
        layer_path = pending.pop()
        if layer_path in visited:
            continue
        visited.add(layer_path)
        if len(visited) > 256:
            raise ValueError('Trop de couches USD liées pour ce prototype')
        layer = Sdf.Layer.FindOrOpen(str(layer_path))
        if layer is None:
            raise ValueError('Couche USD illisible')
        for token in re.findall(r'@([^@]*)@', layer.ExportToString()):
            if not token:
                continue
            # Conservative: disallow URIs, absolute paths, patterns and traversal
            # before touching the dependency. Nothing is fetched remotely.
            dep = Path(token)
            if dep.is_absolute() or ':' in token or '..' in dep.parts or '<' in token or '[' in token:
                raise ValueError(f'Ressource externe non prise en charge : {token}')
            candidate = layer_path.parent / dep
            if not candidate.is_relative_to(root):
                raise ValueError('Ressource hors bibliothèque')
            for part in (candidate, *candidate.parents):
                if part == root:
                    break
                if is_link(part):
                    raise ValueError('Ressource liée refusée')
            candidate = candidate.resolve(strict=True)
            if not candidate.is_relative_to(root):
                raise ValueError('Ressource hors bibliothèque')
            if candidate.suffix.lower() in {'.usd', '.usda', '.usdc'}:
                pending.append(candidate)
    return path


def import_model(context, root, relative):
    path = checked_asset(root, relative)
    before = set(bpy.data.objects)
    before_collections = set(bpy.data.collections)
    frame = (context.scene.frame_start, context.scene.frame_end, context.scene.frame_current)
    unit = context.scene.unit_settings.scale_length
    world = context.scene.world
    result = bpy.ops.wm.usd_import(
        filepath=str(path), create_collection=True, set_frame_range=False,
        import_cameras=False, import_lights=False, import_volumes=False,
        create_world_material=False, import_textures_mode='IMPORT_PACK',
        mtl_name_collision_mode='MAKE_UNIQUE', validate_meshes=True)
    context.scene.frame_start, context.scene.frame_end = frame[:2]
    context.scene.frame_set(frame[2])
    context.scene.unit_settings.scale_length = unit
    context.scene.world = world
    if result != {'FINISHED'}:
        raise RuntimeError('Import USD non terminé ; vérifier la scène avant de réessayer')
    objects = [o for o in bpy.data.objects if o not in before]
    if not objects:
        raise ValueError('Aucun objet importable dans ce fichier USD')
    # Wrapper retains all source transforms and enables native collection assets.
    collection = bpy.data.collections.new(path.stem)
    context.scene.collection.children.link(collection)
    imported_collections = set(bpy.data.collections) - before_collections - {collection}
    children = {child for parent in imported_collections for child in parent.children}
    for top in imported_collections - children:
        collection.children.link(top)
        if top.name in context.scene.collection.children:
            context.scene.collection.children.unlink(top)
    for obj in objects:
        if not any(owner in imported_collections for owner in obj.users_collection):
            collection.objects.link(obj)
            if obj.name in context.scene.collection.objects:
                context.scene.collection.objects.unlink(obj)
    collection['sand3d_source'] = str(path)
    collection['sand3d_library'] = root
    return collection, objects
