"""Viewport gallery with deterministic hit boxes and enlarged hover preview."""
import bpy
import gpu
import blf
from gpu_extras.batch import batch_for_shader
from gpu_extras.presets import draw_texture_2d
from . import thumbnails

ACTIVE=None


def rect(x,y,w,h,color):
    shader=gpu.shader.from_builtin('UNIFORM_COLOR')
    batch=batch_for_shader(shader,'TRI_FAN',{'pos':[(x,y),(x+w,y),(x+w,y+h),(x,y+h)]})
    shader.bind()
    shader.uniform_float('color',color)
    batch.draw(shader)


def text(x,y,value,size=12):
    blf.size(0,size)
    blf.position(0,x,y,0)
    blf.color(0,0.95,0.95,0.95,1)
    blf.draw(0,value)


class S3D_OT_gallery(bpy.types.Operator):
    bl_idname='sand3d.gallery'
    bl_label='Galerie : miniatures et aperçu au survol'
    bl_description='Galerie dans la vue 3D ; survol agrandi, clic pour sélectionner, Échap pour fermer'

    def geometry(self):
        width,height=self.region.width,self.region.height
        cols=max(1,min(4,int((width-min(300,width*0.4)-90)//116)))
        rows=max(1,int((height-85)//125))
        return width,height,cols,rows

    def invoke(self,context,event):
        global ACTIVE
        if ACTIVE is not None:
            ACTIVE.finish(context)
            return {'CANCELLED'}
        if context.area is None or context.area.type!='VIEW_3D':
            return {'CANCELLED'}
        self.area=context.area
        self.region=next(r for r in self.area.regions if r.type=='WINDOW')
        self.offset=0
        self.hover=-1
        self.textures={}
        self.handler=bpy.types.SpaceView3D.draw_handler_add(self.draw_overlay,(), 'WINDOW','POST_PIXEL')
        self.timer=context.window_manager.event_timer_add(0.1,window=context.window)
        ACTIVE=self
        context.window_manager.modal_handler_add(self)
        self.area.tag_redraw()
        return {'RUNNING_MODAL'}

    def draw_preview(self,item,x,y,w,h):
        preview=thumbnails.preview(item)
        if preview is None or not preview.image_size[0]:
            thumbnails.request(item)
            text(x+5,y+h/2,item.format.upper(),16)
            return
        key=thumbnails.cache_key(item)
        if key not in self.textures:
            if len(self.textures)>=48:
                self.textures.clear()
            pw,ph=preview.image_size
            buffer=gpu.types.Buffer('FLOAT',pw*ph*4,list(preview.image_pixels_float))
            self.textures[key]=gpu.types.GPUTexture((pw,ph),format='RGBA16F',data=buffer)
        texture=self.textures[key]
        ratio=min(w/texture.width,h/texture.height)
        draw_texture_2d(texture,(x+(w-texture.width*ratio)/2,y+(h-texture.height*ratio)/2),texture.width*ratio,texture.height*ratio)

    def draw_overlay(self):
        if bpy.context.area!=self.area:
            return
        state=bpy.context.window_manager.sand3d_state
        width,height,cols,rows=self.geometry()
        gpu.state.blend_set('ALPHA')
        try:
            rect(8,8,width-16,height-16,(0.045,0.05,0.06,0.97))
            text(65,height-55,'POWER IMPORTER — Survol : aperçu · Clic : sélectionner · Molette : page · Échap : fermer')
            for slot,index in enumerate(range(self.offset,min(len(state.results),self.offset+cols*rows))):
                col,row=slot%cols,slot//cols
                x,y=65+col*116,height-65-(row+1)*125
                rect(x,y,108,116,(0.15,0.27,0.36,1) if index==state.selected else (0.1,0.11,0.13,1))
                item=state.results[index]
                self.draw_preview(item,x+4,y+25,100,86)
                name=item.relative_path.replace('\\','/').rsplit('/',1)[-1]
                text(x+4,y+8,name[:15],11)
            index=self.hover if 0<=self.hover<len(state.results) else state.selected
            px=70+cols*116
            if 0<=index<len(state.results):
                item=state.results[index]
                self.draw_preview(item,px,100,max(50,width-px-25),max(60,height-170))
                text(px,70,item.relative_path.replace('\\','/').rsplit('/',1)[-1][:50])
                text(px,45,'Format : '+item.format.upper())
            text(22,22,f'{len(state.results)} résultat(s) · page {self.offset//(cols*rows)+1}',11)
        finally:
            gpu.state.blend_set('NONE')

    def modal(self,context,event):
        if not any(area==self.area for area in context.screen.areas) or event.type=='ESC':
            self.finish(context)
            return {'CANCELLED'}
        x,y=event.mouse_x-self.region.x,event.mouse_y-self.region.y
        width,height,cols,rows=self.geometry()
        inside=0<=x<width and 0<=y<height
        if inside and event.type in {'WHEELUPMOUSE','WHEELDOWNMOUSE'}:
            step=cols*rows
            count=len(context.window_manager.sand3d_state.results)
            self.offset=max(0,min(max(0,((count-1)//step)*step),self.offset+(step if event.type=='WHEELDOWNMOUSE' else -step)))
            self.hover=-1
            self.area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type=='MOUSEMOVE' and inside:
            col=int((x-65)//116)
            row=int((height-65-y)//125)
            index=self.offset+row*cols+col
            self.hover=index if x>=65 and 0<=col<cols and 0<=row<rows and index<len(context.window_manager.sand3d_state.results) else -1
            self.area.tag_redraw()
        if event.type=='LEFTMOUSE' and event.value=='PRESS' and inside and self.hover>=0:
            context.window_manager.sand3d_state.selected=self.hover
            return {'RUNNING_MODAL'}
        if event.type=='TIMER':
            self.area.tag_redraw()
        return {'RUNNING_MODAL'} if inside else {'PASS_THROUGH'}

    def finish(self,context):
        global ACTIVE
        if getattr(self,'handler',None):
            bpy.types.SpaceView3D.draw_handler_remove(self.handler,'WINDOW')
            self.handler=None
        if getattr(self,'timer',None):
            context.window_manager.event_timer_remove(self.timer)
            self.timer=None
        self.textures.clear()
        try:
            self.area.tag_redraw()
        except ReferenceError:
            pass
        ACTIVE=None

    def cancel(self,context):
        self.finish(context)


def register():
    bpy.utils.register_class(S3D_OT_gallery)


def unregister():
    if ACTIVE is not None:
        ACTIVE.finish(bpy.context)
    bpy.utils.unregister_class(S3D_OT_gallery)
